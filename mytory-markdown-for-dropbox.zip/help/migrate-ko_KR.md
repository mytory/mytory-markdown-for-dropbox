드롭박스 폴더에 해당하는 URL을 아래 항목에 입력하세요.

예컨대, URL이 `https://dl.dropboxusercontent.com/u/15546257/md/a.md`이고 드롭박스 안의 경로가
`/Public/md/a.md`라면 드롭박스 폴더에 해당하는 URL은 `dl.dropboxusercontent.com/u/15546257/`입니다.

URL을 입력할 때 `http://`나 `https://`는 쓰지 마세요. URL 맨 마지막엔 `/`를 붙여야 합니다.
